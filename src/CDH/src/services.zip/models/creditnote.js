import mongoose from 'mongoose';

const creditNoteSchema = new mongoose.Schema({
  date:
  {
    type: Date,
    required: true,
  },
  center:
  {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Center',
    required: true,
  },
  doctor:
  {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Doctor',
    required: true,
  },
  patientCenter:
  {
    type: String,
    required: true,
  },
  patient:
  {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Patient',
    required: true,
  },
  amount:
  {
    type: Number,
    required: true,
  },
  note:
  {
    type: String,
  },
  voucherStatus:
  {
    type: String,
    enum: ['Regular', 'Discounted', 'Refunded'],
    default: 'Regular'
  },
},{timestamps:true});

export default mongoose.model('CreditNote', creditNoteSchema);
