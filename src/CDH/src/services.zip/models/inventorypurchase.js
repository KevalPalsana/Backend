import mongoose from 'mongoose';

const inventoryPurchaseSchema = new mongoose.Schema({
    center:
    {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Center',
        required: true
    },
    billEntryDate:
    {
        type: Date,
        required: true
    },
    vendor:
    {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Vendor',
        required: true
    },
    billNo:
    {
        type: String,
        required: true
    },
    billDate:
    {
        type: Date,
        required: true
    },
    items:
        [
            {
                item:
                {
                    type: mongoose.Schema.Types.ObjectId,
                    ref: 'InventoryItem',
                    required: true
                },
                lastPrice:
                {
                    type: Number,
                    required: true
                },
                price:
                {
                    type: Number,
                    required: true
                },
                qty:
                {
                    type: Number,
                    required: true
                },
                disc:
                {
                    type: Number,
                    default: 0
                },
                net:
                {
                    type: Number,
                    required: true
                },
                tax:
                {
                    type: Number,
                    default: 0
                },
                total:
                {
                    type: Number,
                    required: true
                },
                notes:
                {
                    type: String,
                },
                others:
                {
                    type: Number,
                    default: 0
                },
                particulars:
                {
                    type: String,
                }
            }
        ],
    notes:
    {
        type: String,
    },
    image:
    {
        type: String
    }
},{timestamps:true});

export default mongoose.model('InventoryPurchase', inventoryPurchaseSchema);

