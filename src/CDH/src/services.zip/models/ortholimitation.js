import mongoose from 'mongoose';

const ortholimitationSchema = new mongoose.Schema({
  limitaion: {
    type: String,
    required: true
  },
  notes: {
    type: String,
  },
  active: {
    type: Boolean,
    default: true
  }
});

export default mongoose.model('Ortholimitation', ortholimitationSchema);
