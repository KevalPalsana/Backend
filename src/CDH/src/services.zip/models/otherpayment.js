import mongoose from 'mongoose';

const otherSchema = new mongoose.Schema({
    otherName: {
        type: String,
        required: true
    },
    searchWords:
    {
        type: String
    },
    active:
    {
        type: Boolean,
        default: false,
    },
    default:
    {
        type: Boolean,
        default: false,
    },
    notes: {
        type: String,
        default: ''
    }
});

export default mongoose.model('Other', otherSchema);
