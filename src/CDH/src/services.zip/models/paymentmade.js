import mongoose from 'mongoose';

const paymentMadeSchema = new mongoose.Schema({
  date:
  {
    type: Date,
    required: true
  },
  center:
  {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Center',
    required: true
  },
  image:
  {
    type: String
  },
  madeTo:
  {
    type: String,
    enum: ['Vendor', 'Doctor/Staff', 'Expense Account'],
    required: true
  },
  vendor:
  {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Vendor',
    required: true
  },
  paymentMode:
  {
    type: String,
    enum: ['Cash', 'Cheque/NEFT/RTGS', 'Card', 'Wallet', 'Other'],
    required: true
  },
  amount:
  {
    type: Number,
    required: true
  },
  note:
  {
    type: String,
  },
  printPayment:
  {
    type: Boolean,
    default: false
  }
},{timestamps:true});

export default mongoose.model('PaymentMade', paymentMadeSchema);

