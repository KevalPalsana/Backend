import mongoose from 'mongoose';

const accountSchema = new mongoose.Schema({
  accountName:
   {
    type: String,
    required: true,
  },
  accountGroup: 
  {
    type: String,
    required: true
  },
  searchWords:
   {
    type: String,
  },
  notes:
   {
    type: String,
  },
  // status:
  // {
  //   type: String,
  //   enum: ['Active', 'Inactive'],
  //   default: 'Inactive'
  // },
  active:
  {
    type: Boolean,

  }
},{timestamps:true});

export default mongoose.model('Account', accountSchema);
