import mongoose from 'mongoose';

const labBillSchema = new mongoose.Schema({
    center:
    {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Center',
        required: true
    },
    billEntryDate:
    {
        type: Date,
        required: true
    },
    lab:
    {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Lab',
        required: true
    },
    billNo:
    {
        type: String,
        required: true
    },
    billDate:
    {
        type: Date,
        required: true
    },
    image:
    {
        type: String
    }
},{timestamps:true});

export default mongoose.model('LabBill', labBillSchema);

