import mongoose from 'mongoose';

const paymentreceivedSchema = new mongoose.Schema({
  date:
  {
    type: Date,
  },
  Center:
  {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Center',
  },
  receivedFrom:
  {
    type: String,
    enum: ['Patient', 'Ratecard'],
    default:'Patient'
    // required: true
  },
  patient:
  {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Patient',
  },
  amount:
  {
    type: Number,
  },
  paymentMode:
  {
    type: String,
    enum: ['Cash', 'Cheque/NEFT/RTGS', 'Card', 'Wallet', 'Other'],
  },
  doctor:
  {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Doctor',
  },
  note:
  {
    type: String,
  }
},{timestamps:true});

export default mongoose.model('Paymentreceived', paymentreceivedSchema);

