import mongoose from 'mongoose';

const clinicalNotesSchema = new mongoose.Schema({
  clinicalNotesType: {
    type: String,
    required: true
  },
  notes: {
    type: String,
    required: true
  },
  remark: {
    type: String,
  },
  active: {
    type: Boolean,
    default: true
  }
});

export default mongoose.model('ClinicalNotes', clinicalNotesSchema);
