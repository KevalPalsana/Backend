import mongoose from 'mongoose';

const journalEntrySchema = new mongoose.Schema({
  date:
  {
    type: Date,
    required: true
  },
  center:
  {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Center',
    required: true,
  },
  debitAccountType:
  {
    type: String,
    enum: ['Doctor/Staff', 'Vendor', 'Account'],
    required: true
  },
  Doctor1:
  {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Doctor',
    required: true
  },
  creditAccountType:
  {
    type: String,
    enum: ['Doctor/Staff', 'Vendor', 'Account'],
    required: true
  },
  Doctor2:
  {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Doctor',
    required: true
  },
  amount:
  {
    type: Number,
    required: true
  },
  note:
  {
    type: String,
  }
},{timestamps:true});

export default mongoose.model('JournalEntry', journalEntrySchema);