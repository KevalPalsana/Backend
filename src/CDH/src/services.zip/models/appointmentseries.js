import mongoose from 'mongoose';

const appointmentSeriesSchema = new mongoose.Schema({
  center: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Center',
  },
  patient: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Patient',
  },
  doctor: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Doctor',
  },
  treatmentCategory: {
    type: String,
    default: 'TreatmentCategory',
  },
  appointmentseries:
  {
    type:String
  },
  operatory: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Operatory',
  },
  date: {
    type: Date,
  },
  time: {
    type: String,
  },
}, { timestamps: true });

export default mongoose.model('AppointmentSeries', appointmentSeriesSchema);
