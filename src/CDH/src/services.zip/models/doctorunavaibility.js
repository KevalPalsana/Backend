import mongoose from 'mongoose';

const doctorUnavailabilitySchema = new mongoose.Schema({
  doctorId:
  {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Doctor',
    
  },
  unavailableFrom:
  {
    type: Date,
    
  },
  unavailableFromTime:
  {
    type: String,
    
  },
  upTo:
  {
    type: Date,
    
  },
  upToTime:
  {
    type: String,
    
  },
  reason:
  {
    type: String,
    
  },
  description:
  {
    type: String,
  }
},{timestamps:true});

export default mongoose.model('DoctorUnavailability', doctorUnavailabilitySchema);
