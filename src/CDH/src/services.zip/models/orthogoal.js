import mongoose from 'mongoose';

const orthoGoalSchema = new mongoose.Schema({
  goal: {
    type: String,
    required: true
  },
  notes: {
    type: String,
  },
  active: {
    type: Boolean,
    default: true
  }
});

export default mongoose.model('OrthoGoal', orthoGoalSchema);
