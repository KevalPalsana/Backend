import mongoose from 'mongoose';

const cashBankTransactionSchema = new mongoose.Schema({
  date:
  {
    type: Date,
    required: true
  },
  transactionType:
  {
    type: String,
    enum: ['Withdrawal', 'Deposit', 'Transfer'],
    required: true
  },
  bank:
  {
    type: String,
    required: true
  },
  chequeRefNo:
  {
    type: String,
    required: true,
  },
  chequeRefDate:
  {
    type: Date,
  },
  amount:
  {
    type: Number,
    required: true
  },
  note:
  {
    type: String,
  }
},{timestamps:true});

export default mongoose.model('CashBankTransaction', cashBankTransactionSchema);

