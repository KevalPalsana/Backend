const orderStatus = ['created', 'processing', 'shipped', 'delivered', 'cancelled']

export default orderStatus;