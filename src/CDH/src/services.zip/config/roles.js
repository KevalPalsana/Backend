const roles = ['user', 'admin', 'manager'];

export default roles;